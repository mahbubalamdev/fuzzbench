# aflplusplus + fuzzolic z3

Simple AFL++ fuzzer instance together with fuzzolic z3

Repository: [https://github.com/AFLplusplus/AFLplusplus/](https://github.com/AFLplusplus/AFLplusplus/)
Repository: [https://github.com/season-lab/fuzzolic](https://github.com/season-lab/fuzzolic)

[builder.Dockerfile](builder.Dockerfile)
[fuzzer.py](fuzzer.py)
[runner.Dockerfile](runner.Dockerfile)
