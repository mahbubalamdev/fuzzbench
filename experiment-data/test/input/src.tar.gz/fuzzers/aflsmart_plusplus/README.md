[AFLSmart++](https://github.com/thuanpv/aflsmart) is an extension of AFLSmart. Like AFLSmart, it is a structure-aware greybox-fuzzer and it is designed to work best for programs taking chunk-based file formats (e.g., JPEG, PNG and many others) as inputs.

